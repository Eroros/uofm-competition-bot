"""
secon26_hw_launch.py
Hardware bringup on Raspberry Pi — no Gazebo.
Runs: rplidar_ros driver, robot_state_publisher, slam_toolbox, Nav2

Prerequisites on Pi:
  sudo apt install ros-humble-rplidar-ros ros-humble-slam-toolbox
                   ros-humble-nav2-bringup ros-humble-robot-localization
  sudo usermod -aG dialout $USER   # access /dev/ttyUSB0 (RPLidar C1 = /dev/ttyUSB0)

Usage:
  ros2 launch secon26_bringup secon26_hw_launch.py

After map is built (drive the arena manually once):
  ros2 run nav2_map_server map_saver_cli -f ~/secon26_maps/arena_map
Then set mode: localization in slam_toolbox_params.yaml and relaunch.
"""

import os
from launch import LaunchDescription
from launch.actions import (
    DeclareLaunchArgument, IncludeLaunchDescription, TimerAction
)
from launch.substitutions import LaunchConfiguration
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():

    pkg_dir  = os.path.dirname(os.path.realpath(__file__))
    pkg_root = os.path.dirname(pkg_dir)

    urdf_file   = os.path.join(pkg_root, 'urdf',   'secon26_bot.urdf')
    slam_config = os.path.join(pkg_root, 'config', 'slam_toolbox_params.yaml')
    nav2_config = os.path.join(pkg_root, 'config', 'nav2_params.yaml')

    use_sim_time = LaunchConfiguration('use_sim_time', default='false')
    autostart    = LaunchConfiguration('autostart',    default='true')

    with open(urdf_file, 'r') as f:
        robot_desc = f.read()

    # ── RPLidar C1 driver ────────────────────────────────────────────────────
    # C1 uses RPLIDAR SDK; channel_type is 'tcp' for C1 (UDP based)
    # Default port on Pi: /dev/ttyUSB0 at 460800 baud
    rplidar = Node(
        package='rplidar_ros',
        executable='rplidar_composition',
        name='rplidar_node',
        output='screen',
        parameters=[{
            'serial_port': '/dev/ttyUSB0',
            'serial_baudrate': 460800,
            'frame_id': 'laser_frame',
            'angle_compensate': True,
            'scan_mode': 'Standard',   # C1 supports Standard mode
        }],
        remappings=[('scan', '/scan')]
    )

    # ── Robot state publisher ─────────────────────────────────────────────────
    rsp = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[{
            'robot_description': robot_desc,
            'use_sim_time': False,
        }]
    )

    # ── Joint state publisher (wheels) ────────────────────────────────────────
    # Replace with your actual motor encoder publisher on hardware
    joint_state_pub = Node(
        package='joint_state_publisher',
        executable='joint_state_publisher',
        name='joint_state_publisher',
        output='screen',
    )

    # ── SLAM Toolbox ──────────────────────────────────────────────────────────
    slam = Node(
        package='slam_toolbox',
        executable='async_slam_toolbox_node',
        name='slam_toolbox',
        output='screen',
        parameters=[
            slam_config,
            {'use_sim_time': False},
        ],
        remappings=[
            ('scan', '/scan'),
            ('odom', '/odom'),
        ]
    )

    # ── Nav2 bringup ──────────────────────────────────────────────────────────
    nav2_dir = get_package_share_directory('nav2_bringup')
    nav2_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(nav2_dir, 'launch', 'navigation_launch.py')
        ),
        launch_arguments={
            'use_sim_time': 'false',
            'autostart': autostart,
            'params_file': nav2_config,
        }.items()
    )

    # ── Mission controller (comment out to drive manually first) ──────────────
    mission = Node(
        package='secon26_bringup',
        executable='secon26_mission_controller',
        name='mission_controller',
        output='screen',
    )

    return LaunchDescription([
        DeclareLaunchArgument('use_sim_time', default_value='false'),
        DeclareLaunchArgument('autostart',    default_value='true'),

        rplidar,
        rsp,
        joint_state_pub,

        # SLAM needs scan + odom — start after drivers are ready
        TimerAction(period=2.0, actions=[slam]),

        # Nav2 after SLAM
        TimerAction(period=5.0, actions=[nav2_launch]),

        # Mission controller last — after Nav2 is ready
        # TimerAction(period=12.0, actions=[mission]),  # uncomment for auto-run
    ])
