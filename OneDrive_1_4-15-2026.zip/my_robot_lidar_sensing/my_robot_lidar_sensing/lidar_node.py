#!/usr/bin/env python3
"""
lidar_node.py
=============
The main LIDAR processing node for the SoutheastCon 2026 robot.

This node sits between the raw RPLIDAR C1 hardware driver (rplidar_ros,
which is your groupmate's package) and everything else in your system.

It does NOT talk to the LIDAR hardware directly — rplidar_ros handles
that and publishes raw scans to /scan.  This node's job is to READ
those raw scans and turn them into useful information that other parts
of your system can act on.

─────────────────────────────────────────────────────────────────────
WHAT THIS NODE PUBLISHES
─────────────────────────────────────────────────────────────────────

  /scan_filtered      (sensor_msgs/LaserScan)
      A cleaned-up version of the raw scan.  Removes readings outside
      the LIDAR's reliable range, fills short gaps, and crops the angle
      range to what is useful for this robot.  Nav2 and SLAM can use
      this instead of the raw /scan if needed.

  /obstacle_distance  (std_msgs/Float32)
      Single number: the closest obstacle anywhere in the robot's
      forward 90° arc (±45° from dead ahead), in metres.
      Used by the mission controller to slow down or stop safely.

  /zone_distances     (std_msgs/String)
      JSON string with distance readings in four named zones:
        {"front": 0.42, "left": 0.81, "right": 0.77, "rear": 1.20}
      All in metres.  "front" is the minimum in ±45°, "left" is
      minimum in 45°–135°, etc.  Useful for wall-following and
      positioning relative to antennas.

  /wall_distances     (std_msgs/String)
      JSON string with estimated distances to the four arena walls:
        {"north": 0.35, "south": 1.82, "east": 0.60, "west": 1.15}
      Computed by taking the max reliable reading in each cardinal
      direction.  Used by the mission controller to sanity-check
      Nav2's pose estimate and to know when the robot is in the
      right area of the arena.

─────────────────────────────────────────────────────────────────────
COORDINATE CONVENTION (important to understand)
─────────────────────────────────────────────────────────────────────

  In ROS2 LaserScan messages:
    angle = 0     means STRAIGHT AHEAD of the robot (+X direction)
    angle = +90°  means to the robot's LEFT  (+Y direction)
    angle = -90°  means to the robot's RIGHT (-Y direction)
    angle = ±180° means DIRECTLY BEHIND the robot

  This is in the ROBOT'S local frame — it rotates as the robot turns.
  It does NOT know about north/south/east/west until Nav2's AMCL
  tells us the robot's heading in the map frame.
  The wall_distances topic makes a simplifying assumption: it treats
  the LIDAR's four quadrants as roughly aligned with the arena walls.
  This is only accurate when the robot is near its known poses.

─────────────────────────────────────────────────────────────────────
HOW THE RPLIDAR C1 WORKS
─────────────────────────────────────────────────────────────────────

  The RPLIDAR C1 spins at ~7-10 Hz and emits ~8000 samples per second.
  Each sample is a distance measurement at a specific angle.
  ROS's rplidar_ros driver groups these into LaserScan messages,
  one message per full 360° rotation.

  Each LaserScan message contains:
    angle_min      — starting angle of this scan (radians)
    angle_max      — ending angle (radians)
    angle_increment — angle between consecutive readings (radians)
    range_min      — minimum reliable distance (m) — below this = noise
    range_max      — maximum reliable distance (m) — above this = too far
    ranges[]       — array of distance readings, one per angle step
                     'inf' or 'nan' means no return at that angle

  The C1 has a range_min of about 0.15m and range_max of about 12m,
  but in a 4'×8' arena the walls are at most ~2.4m away, so
  readings beyond 3.5m are clamped.
"""

import json
import math

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from std_msgs.msg import Float32, String


# ─── Tunable parameters ────────────────────────────────────────────────────────
# These are safe defaults.  Adjust if your robot's LIDAR is mounted differently.

# Hard clamp on what we consider a valid reading (metres)
# Readings below MIN are the robot's own body; above MAX are too far to trust
RANGE_MIN_M = 0.10
RANGE_MAX_M = 3.5

# Half-width of the "forward obstacle" arc in degrees
# ±45° gives a 90° total cone directly ahead of the robot
FRONT_ARC_DEG = 45.0

# ─── Zone arc boundaries (degrees from dead ahead, in ROBOT frame) ────────────
#   front  = -45° to +45°      (straight ahead)
#   left   = +45° to +135°     (robot's left side)
#   rear   = +135° to +180° + -180° to -135°  (behind)
#   right  = -135° to -45°     (robot's right side)
ZONE_BOUNDS = {
    'front': (-45.0,  45.0),
    'left':  ( 45.0, 135.0),
    'rear':  (135.0, 180.0),   # rear is split; handled specially below
    'right': (-135.0, -45.0),
}


def _valid(r: float, range_min: float, range_max: float) -> bool:
    """Return True if a laser reading is a real, usable distance."""
    return math.isfinite(r) and range_min <= r <= range_max


def _angle_in_range(angle_rad: float, lo_deg: float, hi_deg: float) -> bool:
    """
    Check whether an angle (radians, already normalised to [-π, π])
    falls inside [lo_deg, hi_deg].
    """
    a = math.degrees(angle_rad)
    return lo_deg <= a <= hi_deg


class LidarNode(Node):
    """
    Processes raw RPLIDAR C1 scans and publishes useful summaries.
    """

    def __init__(self):
        super().__init__('lidar_node')

        # ── Parameters ────────────────────────────────────────────────────
        self.declare_parameter('range_min',     RANGE_MIN_M)
        self.declare_parameter('range_max',     RANGE_MAX_M)
        self.declare_parameter('front_arc_deg', FRONT_ARC_DEG)

        self._range_min  = self.get_parameter('range_min').value
        self._range_max  = self.get_parameter('range_max').value
        self._front_arc  = math.radians(
            self.get_parameter('front_arc_deg').value)

        # ── Publishers ────────────────────────────────────────────────────
        self._pub_filtered  = self.create_publisher(
            LaserScan, '/scan_filtered',     10)
        self._pub_obstacle  = self.create_publisher(
            Float32,   '/obstacle_distance', 10)
        self._pub_zones     = self.create_publisher(
            String,    '/zone_distances',    10)
        self._pub_walls     = self.create_publisher(
            String,    '/wall_distances',    10)

        # ── Subscriber ────────────────────────────────────────────────────
        # Every time rplidar_ros publishes a new 360° scan, _scan_cb runs.
        self.create_subscription(LaserScan, '/scan', self._scan_cb, 10)

        self.get_logger().info('LidarNode started — listening on /scan')

    # ─────────────────────────────────────────────────────────────────────
    # MAIN CALLBACK — runs once per LIDAR rotation (~10 Hz)
    # ─────────────────────────────────────────────────────────────────────

    def _scan_cb(self, msg: LaserScan):
        """
        Called automatically every time a full 360° scan arrives.

        We do everything in one pass through the ranges[] array to keep
        it efficient — the Pi 4 is fast enough, but no need to iterate
        the array multiple times.
        """

        # Buckets for each zone — we collect all valid readings per zone
        zone_readings = {z: [] for z in ZONE_BOUNDS}

        # Filtered ranges array — same length as original, bad values replaced
        filtered_ranges = list(msg.ranges)

        angle = msg.angle_min

        for i, r in enumerate(msg.ranges):

            # ── Normalise angle to [-π, π] ────────────────────────────────
            # angle_min might be -π and angle_max +π, but floating point
            # can push individual values slightly outside.
            norm = math.atan2(math.sin(angle), math.cos(angle))
            deg  = math.degrees(norm)

            # ── Validate reading ──────────────────────────────────────────
            is_valid = _valid(r, self._range_min, self._range_max)

            if not is_valid:
                # Replace bad reading with range_max (treat as "nothing there")
                filtered_ranges[i] = self._range_max
            else:
                # Clamp to our chosen max
                filtered_ranges[i] = min(r, self._range_max)

            # ── Bin into zones ────────────────────────────────────────────
            if is_valid:
                if   -45.0  <= deg <=  45.0:
                    zone_readings['front'].append(r)
                elif  45.0  <  deg <= 135.0:
                    zone_readings['left'].append(r)
                elif -135.0 <= deg <  -45.0:
                    zone_readings['right'].append(r)
                else:
                    # rear: |deg| > 135
                    zone_readings['rear'].append(r)

            angle += msg.angle_increment

        # ── Publish filtered scan ─────────────────────────────────────────
        filtered_msg = LaserScan()
        filtered_msg.header          = msg.header
        filtered_msg.angle_min       = msg.angle_min
        filtered_msg.angle_max       = msg.angle_max
        filtered_msg.angle_increment = msg.angle_increment
        filtered_msg.time_increment  = msg.time_increment
        filtered_msg.scan_time       = msg.scan_time
        filtered_msg.range_min       = self._range_min
        filtered_msg.range_max       = self._range_max
        filtered_msg.ranges          = filtered_ranges
        self._pub_filtered.publish(filtered_msg)

        # ── Publish closest obstacle in front arc ─────────────────────────
        front = zone_readings['front']
        closest_front = min(front) if front else self._range_max
        obs_msg       = Float32()
        obs_msg.data  = float(closest_front)
        self._pub_obstacle.publish(obs_msg)

        # ── Publish zone summary ──────────────────────────────────────────
        zone_mins = {
            z: float(min(v)) if v else float(self._range_max)
            for z, v in zone_readings.items()
        }
        zone_str      = String()
        zone_str.data = json.dumps({k: round(v, 3) for k, v in zone_mins.items()})
        self._pub_zones.publish(zone_str)

        # ── Publish wall distance estimate ────────────────────────────────
        # Wall = the FARTHEST reading in each zone (i.e. the reading that
        # "sees through" to the wall rather than hitting a nearer object).
        # This is a heuristic — it works well in the open arena but can
        # be confused by ducks, antennas, or the crater.
        wall_maxes = {
            z: float(max(v)) if v else float(self._range_max)
            for z, v in zone_readings.items()
        }
        # Rename to cardinal directions (assuming robot starts facing east)
        wall_str      = String()
        wall_str.data = json.dumps({
            'north': round(wall_maxes['left'],  3),
            'south': round(wall_maxes['right'], 3),
            'east':  round(wall_maxes['front'], 3),
            'west':  round(wall_maxes['rear'],  3),
        })
        self._pub_walls.publish(wall_str)

        self.get_logger().debug(
            f'front_min={closest_front:.2f}m  zones={zone_mins}')


# ─── Entry point ──────────────────────────────────────────────────────────────
def main(args=None):
    rclpy.init(args=args)
    node = LidarNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
