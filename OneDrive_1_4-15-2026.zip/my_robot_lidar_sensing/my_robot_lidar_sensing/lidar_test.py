#!/usr/bin/env python3
"""
lidar_test.py
=============
A simple diagnostic node to verify the RPLIDAR C1 is working correctly.

This is a TEST script — run it first before using lidar_node.py to confirm
that the hardware is connected and data is flowing.

WHAT IT DOES:
  - Subscribes to /scan (published by rplidar_ros driver)
  - Prints a human-readable summary every second:
      * Number of readings in this scan
      * Closest obstacle and which direction it's at
      * Average distance in each quadrant

IMPORTANT:
  This node does NOT talk to the LIDAR hardware directly.
  The rplidar_ros driver must already be running before you start this node.
  Your groupmate's secon26_hw_launch.py starts rplidar_ros automatically.

HOW TO RUN:
  # Terminal 1 — start the hardware drivers (includes rplidar_ros):
  ros2 launch secon26_bringup secon26_hw_launch.py

  # Terminal 2 — run this test node:
  ros2 run my_robot_lidar_sensing lidar_test

  # You should see output like:
  # [lidar_test] Scan #1 | 800 rays | closest: 0.42m @ 5.0° | F:0.65 L:0.90 R:0.88 B:1.20
"""

import math
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan


class LidarTest(Node):
    def __init__(self):
        super().__init__('lidar_test')

        self._scan_count = 0

        # Subscribe to the raw scan topic that rplidar_ros publishes
        self.create_subscription(LaserScan, '/scan', self._scan_cb, 10)

        # Print a status message every 1 second even if no scans arrive
        self.create_timer(1.0, self._heartbeat)

        self.get_logger().info(
            'LidarTest started — waiting for scans on /scan ...')
        self.get_logger().info(
            'Make sure rplidar_ros is running (secon26_hw_launch.py)')

    def _scan_cb(self, msg: LaserScan):
        """Process each incoming scan and print a one-line summary."""
        self._scan_count += 1

        valid_readings = []  # list of (angle_deg, distance_m) tuples

        angle = msg.angle_min
        for r in msg.ranges:
            # Only keep readings within the sensor's reliable range
            if math.isfinite(r) and msg.range_min < r < msg.range_max:
                valid_readings.append((math.degrees(angle), r))
            angle += msg.angle_increment

        if not valid_readings:
            self.get_logger().warn(f'Scan #{self._scan_count}: NO valid readings!')
            return

        # Find the closest obstacle overall
        closest_angle, closest_dist = min(valid_readings, key=lambda x: x[1])

        # Bucket into four quadrants and find average per quadrant
        front = [r for a, r in valid_readings if -45 <= a <= 45]
        left  = [r for a, r in valid_readings if  45 <  a <= 135]
        right = [r for a, r in valid_readings if -135 <= a < -45]
        rear  = [r for a, r in valid_readings if abs(a) > 135]

        avg = lambda lst: sum(lst) / len(lst) if lst else float('nan')

        self.get_logger().info(
            f'Scan #{self._scan_count:4d} | '
            f'{len(valid_readings):4d} rays | '
            f'closest: {closest_dist:.2f}m @ {closest_angle:+.1f}° | '
            f'F:{avg(front):.2f} '
            f'L:{avg(left):.2f} '
            f'R:{avg(right):.2f} '
            f'B:{avg(rear):.2f}'
        )

    def _heartbeat(self):
        """Warn if no scans are arriving."""
        if self._scan_count == 0:
            self.get_logger().warn(
                'No scans received yet. Is rplidar_ros running? '
                'Try: ros2 topic list | grep scan')


def main(args=None):
    rclpy.init(args=args)
    node = LidarTest()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
