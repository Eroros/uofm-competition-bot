"""
lidar_launch.py
===============
Launches the my_robot_lidar_sensing processing node alongside the
rplidar_ros hardware driver.

USE THIS when you want BOTH the raw LIDAR driver AND your processing
node running together — for example during standalone lidar testing.

For full competition runs, secon26_hw_launch.py already starts
rplidar_ros.  In that case, just run lidar_node separately:
  ros2 run my_robot_lidar_sensing lidar_node

HOW TO RUN THIS LAUNCH FILE:
  ros2 launch my_robot_lidar_sensing lidar_launch.py

OPTIONAL ARGUMENTS:
  ros2 launch my_robot_lidar_sensing lidar_launch.py serial_port:=/dev/ttyUSB1
"""

import os
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory


def generate_launch_description():

    # ── Launch arguments (can be overridden on command line) ──────────────────
    serial_port_arg = DeclareLaunchArgument(
        'serial_port',
        default_value='/dev/ttyUSB0',
        description='Serial port the RPLIDAR C1 is connected to'
    )
    range_max_arg = DeclareLaunchArgument(
        'range_max',
        default_value='3.5',
        description='Maximum LIDAR range to use (metres)'
    )

    serial_port = LaunchConfiguration('serial_port')
    range_max   = LaunchConfiguration('range_max')

    # ── Node 1: rplidar_ros hardware driver ───────────────────────────────────
    # This is the driver that talks to the physical RPLIDAR C1 over USB.
    # It reads the raw sensor data and publishes it as a LaserScan on /scan.
    # This is the SAME node your groupmate already has in secon26_hw_launch.py.
    # We include it here so this launch file is self-contained for testing.
    rplidar_node = Node(
        package='rplidar_ros',
        executable='rplidar_composition',
        name='rplidar_node',
        output='screen',
        parameters=[{
            'serial_port':      serial_port,
            'serial_baudrate':  460800,   # RPLIDAR C1 uses 460800 baud
            'frame_id':         'laser_frame',
            'angle_compensate': True,
            'scan_mode':        'Standard',
        }],
        remappings=[('scan', '/scan')]
    )

    # ── Node 2: our lidar processing node ─────────────────────────────────────
    # Reads /scan from rplidar_ros and publishes:
    #   /scan_filtered     — cleaned scan
    #   /obstacle_distance — closest thing ahead
    #   /zone_distances    — min distance per quadrant
    #   /wall_distances    — estimated distance to each arena wall
    lidar_node = Node(
        package='my_robot_lidar_sensing',
        executable='lidar_node',
        name='lidar_node',
        output='screen',
        parameters=[{
            'range_min':     0.10,
            'range_max':     range_max,
            'front_arc_deg': 45.0,
        }]
    )

    return LaunchDescription([
        serial_port_arg,
        range_max_arg,
        rplidar_node,
        lidar_node,
    ])
