from setuptools import find_packages, setup
import os
from glob import glob

package_name = 'my_robot_lidar_sensing'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        # Required by every ROS2 Python package — do not remove
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),

        # Install launch files so "ros2 launch my_robot_lidar_sensing ..."
        # can find them after "colcon build"
        (os.path.join('share', package_name, 'launch'),
            glob('launch/*.py')),

        # Install config files so they can be found with
        # get_package_share_directory() in launch files
        (os.path.join('share', package_name, 'config'),
            glob('config/*.yaml')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='rohith-rajeev',
    maintainer_email='rajeevrohith10@gmail.com',
    description='LIDAR sensing and processing for SoutheastCon 2026 robot',
    license='MIT',
    extras_require={
        'test': ['pytest'],
    },
    entry_points={
        'console_scripts': [
            # "ros2 run my_robot_lidar_sensing lidar_node"
            # → runs main() in lidar_node.py
            'lidar_node = my_robot_lidar_sensing.lidar_node:main',

            # "ros2 run my_robot_lidar_sensing lidar_test"
            # → runs main() in lidar_test.py
            # Use this first to verify hardware is working
            'lidar_test = my_robot_lidar_sensing.lidar_test:main',
        ],
    },
)
