from setuptools import find_packages, setup

package_name = 'my_robot_hardware_interface'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='rohith-rajeev',
    maintainer_email='rajeevrohith10@gmail.com',
    description='Hardware interface — affector (duck collector) servo driver',
    license='MIT',
    extras_require={
        'test': ['pytest'],
    },
    entry_points={
        'console_scripts': [
            # This line tells ROS2 how to run the node.
            # Format: 'executable_name = package_name.module_name:function_name'
            # So "ros2 run my_robot_hardware_interface affector_driver"
            # will call the main() function in affector_driver.py
            'affector_driver = my_robot_hardware_interface.affector_driver:main',
        ],
    },
)
