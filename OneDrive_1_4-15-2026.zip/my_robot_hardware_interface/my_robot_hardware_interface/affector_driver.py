#!/usr/bin/env python3
"""
affector_driver.py
==================
ROS 2 Humble node that controls the two affector (duck-collector) panels
using two independent servo motors, and uses the RPLIDAR C1 /scan topic
to automatically detect when a duck is between the affectors.

─────────────────────────────────────────────────────────────────
SERVO WIRING  (BCM GPIO numbers — update SERVO_LEFT_PIN / SERVO_RIGHT_PIN
               if your wiring is different)

  Left  affector servo  : GPIO 23  (Physical pin 16)
  Right affector servo  : GPIO 16  (Physical pin 36)

  All servos are standard 50 Hz PWM:
    Pulse width 500 µs  =   0°  (fully closed / folded inward)
    Pulse width 1500 µs =  90°  (parallel to robot sides — "open / collecting")
    Pulse width 2500 µs = 180°  (fully folded forward — startup/return position)

  NOTE: The left and right servos are MIRRORED.  When both are told
  to move to the same logical position, they move in opposite physical
  directions so the panels open symmetrically.

─────────────────────────────────────────────────────────────────
LIDAR DUCK DETECTION EXPLANATION

  The RPLIDAR C1 publishes a full 360° scan on /scan.  We only look at
  a narrow forward arc (the gap between the two affectors) to detect a
  duck sitting between them.

  How it works step by step:
    1.  Every time a new scan arrives, we extract only the readings that
        fall within DUCK_ARC_DEG degrees either side of dead-ahead (0°).
    2.  If ANY of those readings are closer than DUCK_CLOSE_M metres AND
        farther than DUCK_MIN_M metres (to reject the robot body itself),
        we treat that as "duck present between affectors".
    3.  The detection must be confirmed for DUCK_CONFIRM_COUNT consecutive
        scans before the affectors close — this prevents false positives
        from noise or a passing obstacle.
    4.  Once both affectors are closed, we stop checking that arc until
        the affectors are commanded to open again.

─────────────────────────────────────────────────────────────────
STATE MACHINE

  The node maintains a simple state.  The mission controller
  (secon26_mission_controller.py) sends commands by publishing a
  String message to /affector_cmd.  Valid commands:

    "FOLD"     → startup/return position: both panels forward, folded flat
    "OPEN"     → collecting position: panels out to the sides
    "CLOSE"    → holding position: panels partially closed to grip ducks
    "DROP"     → same as OPEN — releases ducks at drop-off zone
    "MANUAL_LEFT:<deg>"   → set left servo to exact angle (testing)
    "MANUAL_RIGHT:<deg>"  → set right servo to exact angle (testing)

  The node publishes its current state on /affector_state (String) so
  the mission controller can read it back.

  It also publishes /affector_duck_count (Int32) — how many ducks it
  believes are currently held.

─────────────────────────────────────────────────────────────────
ANGLES — update these after physical testing on your robot

  FOLD_ANGLE   : both panels swing forward, flat on top of each other
  OPEN_ANGLE   : panels perpendicular to robot body (collecting / dropping)
  CLOSE_1_DUCK : grip angle for 1 duck (tighter than 2 duck grip)
  CLOSE_2_DUCK : grip angle for 2 ducks (slightly more open)
"""

import math
import threading

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from std_msgs.msg import String, Int32

# ─── Try importing GPIO — graceful fallback when not on a Pi ──────────────────
try:
    import RPi.GPIO as GPIO
    HARDWARE = True
except ImportError:
    HARDWARE = False

# ─── GPIO pin assignments (BCM numbering) ─────────────────────────────────────
SERVO_LEFT_PIN  = 23   # Physical pin 16
SERVO_RIGHT_PIN = 16   # Physical pin 36

# ─── PWM settings ─────────────────────────────────────────────────────────────
PWM_FREQ   = 50        # Hz  — standard servo frequency
MIN_PULSE  = 500       # µs  — 0°
MAX_PULSE  = 2500      # µs  — 180°
PERIOD_US  = 20000     # µs  — 1 / 50 Hz

# ─── Affector angle definitions (degrees) ─────────────────────────────────────
# These are the angles sent to BOTH servos simultaneously.
# Adjust after physical testing — the numbers below are reasonable starting
# points based on the CAD image showing ~120° of travel.

FOLD_ANGLE    = 0.0    # Fully folded forward (startup & return to base)
                       # Both panels lie flat on top of each other, parallel
                       # to the robot's front face.

OPEN_ANGLE    = 120.0  # Fully open (panels in line with robot sides)
                       # This is the collecting and dropping angle.

CLOSE_1_DUCK  = 70.0   # Grip angle when holding 1 duck
                       # Enough to stop the duck flying out during turns.

CLOSE_2_DUCK  = 85.0   # Grip angle when holding 2 ducks
                       # Slightly more open than 1-duck to fit both.

# ─── LIDAR duck detection parameters ──────────────────────────────────────────
DUCK_ARC_DEG      = 20.0   # degrees — how wide a forward arc to watch
                            # (total = 2 × 20° = 40° cone ahead of robot)

DUCK_CLOSE_M      = 0.35   # metres — max distance to call it a duck
                            # Tune to roughly the depth of your affector bay.

DUCK_MIN_M        = 0.05   # metres — minimum distance (ignore robot body)

DUCK_CONFIRM_COUNT = 3     # number of consecutive scans that must all agree
                            # before we call it a confirmed duck detection.
                            # At 10 Hz scan rate this is 300 ms of confirmation.

# ─── State names ──────────────────────────────────────────────────────────────
STATE_FOLDED   = 'FOLDED'
STATE_OPEN     = 'OPEN'
STATE_HOLDING  = 'HOLDING'

# ─── Helper: angle → PWM duty cycle ──────────────────────────────────────────
def angle_to_duty(angle_deg: float) -> float:
    """
    Convert a servo angle (0–180°) to a PWM duty cycle percentage
    suitable for RPi.GPIO's ChangeDutyCycle().

    How this works:
      A standard servo expects a pulse every 20 ms (50 Hz).
      The width of that pulse encodes the angle:
        500 µs  = 0°
        1500 µs = 90°
        2500 µs = 180°
      Duty cycle = pulse_width / period × 100
      So 1500 µs / 20000 µs × 100 = 7.5%
    """
    angle_deg = max(0.0, min(180.0, angle_deg))
    pulse_us  = MIN_PULSE + (angle_deg / 180.0) * (MAX_PULSE - MIN_PULSE)
    return (pulse_us / PERIOD_US) * 100.0


class AffectorDriver(Node):
    """
    Controls both affector panels and auto-detects ducks via LIDAR.
    """

    def __init__(self):
        super().__init__('affector_driver')

        # ── Parameters (can be overridden from launch file) ────────────────
        self.declare_parameter('servo_left_pin',     SERVO_LEFT_PIN)
        self.declare_parameter('servo_right_pin',    SERVO_RIGHT_PIN)
        self.declare_parameter('fold_angle',         FOLD_ANGLE)
        self.declare_parameter('open_angle',         OPEN_ANGLE)
        self.declare_parameter('close_1_duck_angle', CLOSE_1_DUCK)
        self.declare_parameter('close_2_duck_angle', CLOSE_2_DUCK)
        self.declare_parameter('duck_arc_deg',       DUCK_ARC_DEG)
        self.declare_parameter('duck_close_m',       DUCK_CLOSE_M)
        self.declare_parameter('duck_min_m',         DUCK_MIN_M)
        self.declare_parameter('duck_confirm_count', DUCK_CONFIRM_COUNT)

        left_pin   = self.get_parameter('servo_left_pin').value
        right_pin  = self.get_parameter('servo_right_pin').value
        self._fold_angle    = self.get_parameter('fold_angle').value
        self._open_angle    = self.get_parameter('open_angle').value
        self._close_1_angle = self.get_parameter('close_1_duck_angle').value
        self._close_2_angle = self.get_parameter('close_2_duck_angle').value
        self._duck_arc      = self.get_parameter('duck_arc_deg').value
        self._duck_close    = self.get_parameter('duck_close_m').value
        self._duck_min      = self.get_parameter('duck_min_m').value
        self._confirm_count = int(self.get_parameter('duck_confirm_count').value)

        # ── Internal state ─────────────────────────────────────────────────
        self._state      = STATE_FOLDED   # current affector state
        self._duck_count = 0              # ducks believed to be held (0, 1, or 2)
        self._detect_buf = 0              # consecutive scans with duck detected
        self._lock       = threading.Lock()

        # ── GPIO / servo setup ─────────────────────────────────────────────
        self._pwm_left  = None
        self._pwm_right = None

        if HARDWARE:
            GPIO.setmode(GPIO.BCM)
            GPIO.setwarnings(False)
            GPIO.setup(left_pin,  GPIO.OUT)
            GPIO.setup(right_pin, GPIO.OUT)

            self._pwm_left  = GPIO.PWM(left_pin,  PWM_FREQ)
            self._pwm_right = GPIO.PWM(right_pin, PWM_FREQ)

            # Start at fold position — robot is in starting box
            self._pwm_left.start(angle_to_duty(self._fold_angle))
            self._pwm_right.start(angle_to_duty(self._fold_angle))

            self.get_logger().info(
                f'GPIO initialised — left pin {left_pin}, right pin {right_pin}')
        else:
            self.get_logger().warn(
                'RPi.GPIO not available — running in simulation mode (no servo output)')

        # ── ROS publishers ─────────────────────────────────────────────────
        self._state_pub = self.create_publisher(String, '/affector_state', 10)
        self._count_pub = self.create_publisher(Int32,  '/affector_duck_count', 10)

        # ── ROS subscribers ────────────────────────────────────────────────
        # Mission controller sends commands here
        self.create_subscription(String, '/affector_cmd',
                                 self._cmd_callback, 10)

        # LIDAR scan — used for duck detection
        self.create_subscription(LaserScan, '/scan',
                                 self._scan_callback, 10)

        # Publish state at 1 Hz so mission controller always has fresh info
        self.create_timer(1.0, self._publish_state)

        self.get_logger().info('Affector driver ready. State: FOLDED')
        self.get_logger().info(
            f'  Angles — fold:{self._fold_angle}° open:{self._open_angle}° '
            f'hold1:{self._close_1_angle}° hold2:{self._close_2_angle}°')
        self.get_logger().info(
            f'  Duck detection — arc:±{self._duck_arc}° '
            f'range:{self._duck_min}–{self._duck_close} m '
            f'confirm:{self._confirm_count} scans')

    # ──────────────────────────────────────────────────────────────────────
    # SECTION 1 — SERVO MOVEMENT
    # ──────────────────────────────────────────────────────────────────────

    def _set_left(self, angle_deg: float):
        """
        Move the LEFT affector servo to the given angle.
        The left servo moves COUNTER-CLOCKWISE to open, so we use the
        angle directly.
        """
        if HARDWARE and self._pwm_left:
            self._pwm_left.ChangeDutyCycle(angle_to_duty(angle_deg))
        self.get_logger().debug(f'Left servo → {angle_deg:.1f}°')

    def _set_right(self, angle_deg: float):
        """
        Move the RIGHT affector servo to the given angle.
        The right servo is MIRRORED — it needs the opposite angle so
        both panels move symmetrically.  We achieve this by subtracting
        from 180°.

        Example: "open" command sends 120° to the left.
                 Right servo receives 180° - 120° = 60°.
                 Both panels swing outward by the same amount.
        """
        mirrored = 180.0 - angle_deg
        if HARDWARE and self._pwm_right:
            self._pwm_right.ChangeDutyCycle(angle_to_duty(mirrored))
        self.get_logger().debug(f'Right servo → {mirrored:.1f}° (mirrored from {angle_deg:.1f}°)')

    def _set_both(self, angle_deg: float):
        """Move both affectors to the same logical angle at the same time."""
        self._set_left(angle_deg)
        self._set_right(angle_deg)

    # ──────────────────────────────────────────────────────────────────────
    # SECTION 2 — HIGH-LEVEL STATE TRANSITIONS
    # ──────────────────────────────────────────────────────────────────────

    def _do_fold(self):
        """
        FOLD — startup position and return-to-base position.
        Both panels swing fully forward and lie flat on top of each other,
        parallel to the robot's front face.
        Resets duck count to 0 (we drop everything before returning home).
        """
        self.get_logger().info('Affectors → FOLD (startup / return position)')
        self._set_both(self._fold_angle)
        with self._lock:
            self._state      = STATE_FOLDED
            self._duck_count = 0
            self._detect_buf = 0
        self._publish_state()

    def _do_open(self):
        """
        OPEN — collecting / dropping position.
        Both panels swing out to be in line with the robot's sides.
        This is also the DROP position — opening releases any held ducks.
        """
        self.get_logger().info('Affectors → OPEN (collecting / dropping)')
        self._set_both(self._open_angle)
        with self._lock:
            self._state      = STATE_OPEN
            self._detect_buf = 0
            # Do NOT reset duck_count here — the mission controller decides
            # whether this is a drop or a collect based on context.
        self._publish_state()

    def _do_close(self, duck_count: int):
        """
        CLOSE — grip position for holding ducks.
        Uses a slightly different angle for 1 vs 2 ducks so the panels
        always press gently against the ducks without crushing them.

        duck_count: how many ducks we now believe are inside.
        """
        angle = self._close_1_angle if duck_count == 1 else self._close_2_angle
        self.get_logger().info(
            f'Affectors → CLOSE (holding {duck_count} duck(s), angle {angle:.1f}°)')
        self._set_both(angle)
        with self._lock:
            self._state      = STATE_HOLDING
            self._duck_count = duck_count
            self._detect_buf = 0  # reset detector so we don't immediately re-trigger
        self._publish_state()

    def _do_drop(self):
        """
        DROP — open at the lunar landing zone to release ducks.
        Identical motion to OPEN, but also resets duck count to 0
        because we are intentionally releasing them.
        """
        self.get_logger().info('Affectors → DROP (releasing ducks at landing zone)')
        self._set_both(self._open_angle)
        with self._lock:
            self._state      = STATE_OPEN
            self._duck_count = 0
            self._detect_buf = 0
        self._publish_state()

    # ──────────────────────────────────────────────────────────────────────
    # SECTION 3 — COMMAND SUBSCRIBER CALLBACK
    # ──────────────────────────────────────────────────────────────────────

    def _cmd_callback(self, msg: String):
        """
        Receives commands from the mission controller on /affector_cmd.

        This is a callback — ROS2 calls this function automatically every
        time a new message arrives on the /affector_cmd topic.

        Valid command strings:
          "FOLD"                 — fold flat for startup/return
          "OPEN"                 — open to collecting width
          "CLOSE"                — close using current duck count
          "DROP"                 — open + reset duck count (at drop zone)
          "MANUAL_LEFT:90"       — move left servo to 90° (testing only)
          "MANUAL_RIGHT:45"      — move right servo to 45° (testing only)
        """
        cmd = msg.data.strip().upper()
        self.get_logger().info(f'Received command: {cmd}')

        if cmd == 'FOLD':
            self._do_fold()

        elif cmd == 'OPEN':
            self._do_open()

        elif cmd == 'CLOSE':
            with self._lock:
                count = self._duck_count
            self._do_close(count if count > 0 else 1)

        elif cmd == 'DROP':
            self._do_drop()

        elif cmd.startswith('MANUAL_LEFT:'):
            # Example: "MANUAL_LEFT:90"
            try:
                angle = float(cmd.split(':')[1])
                self._set_left(angle)
                self.get_logger().info(f'Manual: left servo → {angle}°')
            except (IndexError, ValueError):
                self.get_logger().warn(f'Bad MANUAL_LEFT command: {cmd}')

        elif cmd.startswith('MANUAL_RIGHT:'):
            try:
                angle = float(cmd.split(':')[1])
                self._set_right(angle)
                self.get_logger().info(f'Manual: right servo → {angle}°')
            except (IndexError, ValueError):
                self.get_logger().warn(f'Bad MANUAL_RIGHT command: {cmd}')

        else:
            self.get_logger().warn(f'Unknown affector command: "{cmd}"')

    # ──────────────────────────────────────────────────────────────────────
    # SECTION 4 — LIDAR DUCK DETECTION
    # ──────────────────────────────────────────────────────────────────────

    def _scan_callback(self, msg: LaserScan):
        """
        Called automatically every time the RPLIDAR publishes a new scan.

        This is where we figure out whether a duck is between the affectors.

        Step-by-step explanation:
        ─────────────────────────
        1. We only care when affectors are OPEN (actively collecting).
           If they're folded or already holding max ducks, skip.

        2. We look at the laser readings that point straight ahead of the
           robot, within a ±DUCK_ARC_DEG cone.

        3. The RPLIDAR C1 gives us angles in radians starting from
           msg.angle_min, incrementing by msg.angle_increment.
           We convert our desired arc to radians and check each reading.

        4. A reading counts as "duck detected" if it is:
              > DUCK_MIN_M   (not the robot itself)
              < DUCK_CLOSE_M (within the affector bay depth)

        5. If ANY reading in the arc passes the distance test, we increment
           a confirmation counter.  This counter must reach DUCK_CONFIRM_COUNT
           before we act.  This filters out single noisy readings.

        6. If the counter reaches the threshold, we command the affectors
           to close and update the duck count.
        """
        with self._lock:
            current_state = self._state
            current_ducks = self._duck_count

        # Only try to detect ducks when affectors are open and not already full
        if current_state != STATE_OPEN:
            return
        if current_ducks >= 2:
            return

        # ── Iterate over all laser rays in the forward arc ────────────────
        duck_in_arc = False
        arc_rad     = math.radians(self._duck_arc)

        angle = msg.angle_min
        for r in msg.ranges:
            # Normalise angle to (-π, π] range
            # angle=0 in ROS LaserScan means straight ahead of the robot
            norm_angle = math.atan2(math.sin(angle), math.cos(angle))

            if -arc_rad <= norm_angle <= arc_rad:
                # This ray points into our forward detection arc
                if (msg.range_min < r < msg.range_max  # valid reading
                        and self._duck_min < r < self._duck_close):
                    duck_in_arc = True
                    break  # one hit is enough — no need to check remaining rays

            angle += msg.angle_increment

        # ── Update confirmation buffer ────────────────────────────────────
        with self._lock:
            if duck_in_arc:
                self._detect_buf += 1
                self.get_logger().debug(
                    f'Duck candidate: {self._detect_buf}/{self._confirm_count} scans')
            else:
                # Any scan without a detection resets the buffer.
                # This means we require CONSECUTIVE detections — one miss
                # and we start counting again.
                self._detect_buf = 0

            confirmed = self._detect_buf >= self._confirm_count

        # ── Act on confirmed detection ────────────────────────────────────
        if confirmed:
            new_count = current_ducks + 1
            self.get_logger().info(
                f'Duck confirmed by LIDAR! Duck count: {current_ducks} → {new_count}')
            self._do_close(new_count)

    # ──────────────────────────────────────────────────────────────────────
    # SECTION 5 — STATE PUBLISHING
    # ──────────────────────────────────────────────────────────────────────

    def _publish_state(self):
        """
        Publish current affector state and duck count so the mission
        controller can read them at any time.

        The mission controller subscribes to:
          /affector_state      → String  ("FOLDED", "OPEN", or "HOLDING")
          /affector_duck_count → Int32   (0, 1, or 2)
        """
        with self._lock:
            state = self._state
            count = self._duck_count

        state_msg       = String()
        state_msg.data  = state
        self._state_pub.publish(state_msg)

        count_msg      = Int32()
        count_msg.data = count
        self._count_pub.publish(count_msg)

    # ──────────────────────────────────────────────────────────────────────
    # SECTION 6 — CLEANUP ON SHUTDOWN
    # ──────────────────────────────────────────────────────────────────────

    def cleanup(self):
        """
        Called when the node is shutting down (Ctrl+C or ROS shutdown).
        Parks the affectors in the folded position and releases GPIO.
        """
        self.get_logger().info('Shutting down — parking affectors in FOLD position')
        if HARDWARE:
            self._set_both(self._fold_angle)
            import time
            time.sleep(0.5)  # give servo time to reach position before GPIO releases
            if self._pwm_left:
                self._pwm_left.stop()
            if self._pwm_right:
                self._pwm_right.stop()
            GPIO.cleanup()
            self.get_logger().info('GPIO cleaned up')


# ─── Entry point ──────────────────────────────────────────────────────────────
def main(args=None):
    rclpy.init(args=args)
    node = AffectorDriver()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.cleanup()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
